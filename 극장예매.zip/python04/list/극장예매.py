seat = [[0,0,0,0,0],[0,0,0,0,0]]

def system():
    for i in range(len(seat[0])):
        print("%5d열" % i, end = "  ")
    print()
    print("---------좌석 예매 시스템-----------")
    for x in range(0,2):
        print("%d행:" % x, end=" ")
        for y in range(0,5):
            print(seat[x][y], end= "     ") 
        print()
    print("-------------------------------")
    
while True:
    system()
    row = int(input("예매 행 입력(예매 종료:9)>> "))
    if row in range(0,2):
        col = int(input("예매 열 입력>> "))
        if col in range(0,5):
            if seat[row][col] == 0:
                seat[row][col] = 1
                print("요청한 자리에 예매가 완료됐습니다.\n")
            
            else:
                print("이미 예매 처리된 자리입니다. \n다른 자리를 예매해주세요.\n")
        else:
            print("잘못된 예매 열을 입력하셨습니다.\n")
    
    elif row == 9:
        total = seat[0].count(1) + seat[1].count(1)
        print("\n예매한 좌석수는 %d개입니다." % total)
        print("총 티켓 금액은 %d원입니다." % (total*10000))
        print("예매를 종료합니다.")
        break
    
    else:
        print("잘못된 예매 행을 입력했습니다.\n")
